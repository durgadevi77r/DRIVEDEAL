import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({ 
  plugins: [react()],
  base: process.env.VITE_BASE_PATH || "/",
  build: {
    chunkSizeWarningLimit: 2000,
  },
  server: {
    port: 5173,
    host: 'localhost',
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      }
    }
  }
});